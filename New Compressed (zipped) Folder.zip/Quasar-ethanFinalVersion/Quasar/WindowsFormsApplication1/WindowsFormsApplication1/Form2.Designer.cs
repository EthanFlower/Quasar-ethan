﻿namespace WindowsFormsApplication1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.lbInst = new System.Windows.Forms.Label();
            this.lbObjective = new System.Windows.Forms.Label();
            this.lbDie = new System.Windows.Forms.Label();
            this.lbResult = new System.Windows.Forms.Label();
            this.lbChart = new System.Windows.Forms.Label();
            this.lbBet = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbInst
            // 
            this.lbInst.AutoSize = true;
            this.lbInst.Location = new System.Drawing.Point(13, 13);
            this.lbInst.Name = "lbInst";
            this.lbInst.Size = new System.Drawing.Size(61, 13);
            this.lbInst.TabIndex = 0;
            this.lbInst.Text = "Instructions";
            // 
            // lbObjective
            // 
            this.lbObjective.AutoSize = true;
            this.lbObjective.Location = new System.Drawing.Point(13, 35);
            this.lbObjective.MaximumSize = new System.Drawing.Size(250, 0);
            this.lbObjective.Name = "lbObjective";
            this.lbObjective.Size = new System.Drawing.Size(249, 52);
            this.lbObjective.TabIndex = 1;
            this.lbObjective.Text = "1. The objective of the game is to reach as close to 20 as you possibly can witho" +
    "ut going over by adding dice rolls together each round. Try to get the highest s" +
    "core after 5 rounds.";
            // 
            // lbDie
            // 
            this.lbDie.AutoSize = true;
            this.lbDie.Location = new System.Drawing.Point(13, 126);
            this.lbDie.MaximumSize = new System.Drawing.Size(250, 0);
            this.lbDie.Name = "lbDie";
            this.lbDie.Size = new System.Drawing.Size(242, 52);
            this.lbDie.TabIndex = 2;
            this.lbDie.Text = "3. A random die roll at the beginning starts you off with a number between 1-3. U" +
    "sing the two dice, you choose whether you want to roll a number between 1-8 or 4" +
    "-7.";
            // 
            // lbResult
            // 
            this.lbResult.AutoSize = true;
            this.lbResult.Location = new System.Drawing.Point(13, 178);
            this.lbResult.MaximumSize = new System.Drawing.Size(250, 0);
            this.lbResult.Name = "lbResult";
            this.lbResult.Size = new System.Drawing.Size(237, 39);
            this.lbResult.TabIndex = 3;
            this.lbResult.Text = "4. The number rolled will then be added to your total number. When your total num" +
    "ber goes over 15, you have the option to payout.";
            // 
            // lbChart
            // 
            this.lbChart.AutoSize = true;
            this.lbChart.Location = new System.Drawing.Point(258, 78);
            this.lbChart.MaximumSize = new System.Drawing.Size(150, 0);
            this.lbChart.Name = "lbChart";
            this.lbChart.Size = new System.Drawing.Size(144, 91);
            this.lbChart.TabIndex = 4;
            this.lbChart.Text = resources.GetString("lbChart.Text");
            // 
            // lbBet
            // 
            this.lbBet.AutoSize = true;
            this.lbBet.Location = new System.Drawing.Point(13, 87);
            this.lbBet.MaximumSize = new System.Drawing.Size(250, 0);
            this.lbBet.Name = "lbBet";
            this.lbBet.Size = new System.Drawing.Size(239, 39);
            this.lbBet.TabIndex = 5;
            this.lbBet.Text = "2. Before each round starts, you will be asked to place a bet (minimum 22% of sta" +
    "rting money) that you can attempt to earn back.";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(411, 227);
            this.Controls.Add(this.lbBet);
            this.Controls.Add(this.lbChart);
            this.Controls.Add(this.lbResult);
            this.Controls.Add(this.lbDie);
            this.Controls.Add(this.lbObjective);
            this.Controls.Add(this.lbInst);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbInst;
        private System.Windows.Forms.Label lbObjective;
        private System.Windows.Forms.Label lbDie;
        private System.Windows.Forms.Label lbResult;
        private System.Windows.Forms.Label lbChart;
        private System.Windows.Forms.Label lbBet;
    }
}