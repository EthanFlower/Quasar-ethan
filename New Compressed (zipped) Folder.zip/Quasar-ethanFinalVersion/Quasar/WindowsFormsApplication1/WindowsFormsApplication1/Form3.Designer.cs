﻿namespace WindowsFormsApplication1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttRes = new System.Windows.Forms.Button();
            this.buttQuit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttRes
            // 
            this.buttRes.Location = new System.Drawing.Point(12, 25);
            this.buttRes.Name = "buttRes";
            this.buttRes.Size = new System.Drawing.Size(75, 23);
            this.buttRes.TabIndex = 0;
            this.buttRes.Text = "Restart";
            this.buttRes.UseVisualStyleBackColor = true;
            this.buttRes.Click += new System.EventHandler(this.buttRes_Click);
            // 
            // buttQuit
            // 
            this.buttQuit.Location = new System.Drawing.Point(197, 25);
            this.buttQuit.Name = "buttQuit";
            this.buttQuit.Size = new System.Drawing.Size(75, 23);
            this.buttQuit.TabIndex = 2;
            this.buttQuit.Text = "Quit";
            this.buttQuit.UseVisualStyleBackColor = true;
            this.buttQuit.Click += new System.EventHandler(this.buttQuit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(109, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Game Over!";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(110, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Total Points";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 70);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttQuit);
            this.Controls.Add(this.buttRes);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttRes;
        private System.Windows.Forms.Button buttQuit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}